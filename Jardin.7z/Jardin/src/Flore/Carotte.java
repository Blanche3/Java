package Flore;

public class Carotte extends Vegetal {
	public Carotte(Vegetal dessin) {
		super();
		super.dessin[3] = "c";
		super.dessin[4] = "C";
	}
}
