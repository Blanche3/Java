package Flore;

public class Betterave extends Vegetal {
	public Betterave(Vegetal dessin) {
		super();
		super.dessin[3] = "b";
		super.dessin[4] = "B";
	}

}
