package Flore;

public class Tomate extends Vegetal {
	public Tomate(Vegetal dessin) {
		super();
		super.dessin[3] = "t";
		super.dessin[4] = "T";
	}
}
