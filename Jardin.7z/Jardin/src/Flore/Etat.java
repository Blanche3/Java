package Flore;

public enum Etat {
	GRAINE,
	GERME,
	TIGE,
	FEUILLE,
	FLEUR,
	MORT
}