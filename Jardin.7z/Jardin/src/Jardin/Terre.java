package Jardin;
import Flore.*;
public class Terre {

	public static void main(String[] args) {
		Jardin j = new Jardin(5, 10);
		System.out.println(j.toString());
	}
}
 